import React from 'react';

function Home() {
    return <h2 > Home < /h2>;
}

export default Home;